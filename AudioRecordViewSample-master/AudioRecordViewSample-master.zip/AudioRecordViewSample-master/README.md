*A flexible, efficient library written in Kotlin for drawing real wave forms while recording. Free, easy and convenient to use.*
https://github.com/Armen101/AudioRecordView

Demo: https://youtu.be/RnteDAeydoY
