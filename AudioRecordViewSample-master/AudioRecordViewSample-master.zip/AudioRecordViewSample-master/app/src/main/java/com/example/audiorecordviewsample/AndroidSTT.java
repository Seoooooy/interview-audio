package com.example.audiorecordviewsample;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Toast;

public class AndroidSTT implements RecognitionListener{

    SpeechRecognizer mRecognizer;
    Intent intent; //시작을 통해 음성인식을 지원하는 상수
    Context context;
    Activity activity;

    public void androidSTT(Activity activity){
        //mRecognizer=SpeechRecognizer.createSpeechRecognizer(context);
        this.activity = activity;
        init();

    }//STTstart() end

    public void init(){
        // stt 입력자 생성
        mRecognizer = SpeechRecognizer.createSpeechRecognizer(activity);
        mRecognizer.setRecognitionListener(this);

        // 사용자에게 음성을 요청하고 음성 인식기를 통해 전송하는 활동을 시작함.
        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ko-KR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, // 수행할때 선호하는 음성모델을 인식기에 알림
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); // 자유형식의 음성인식을 기반으로 하는 언어모델 사용

        //intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language); //선택한 언어로 음성인식을 수행
    }//init() end

    public void startAndroidSTT(){
        if(mRecognizer != null && intent != null){
            mRecognizer.startListening(intent);
        }
    }//startAndroidSTT() end

    public void stopAndroidSTT(){
        if(mRecognizer != null){
            mRecognizer.stopListening();
        }
    }//stopAndroidSTT

    //implements RecognitionListener
    @Override
    public void onReadyForSpeech(Bundle params) {
        //사용자가 말할 준비가 되면 호출됨
        Toast.makeText(context,"음성인식을 시작합니다.",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBeginningOfSpeech() {
        // 사용자가 말하기 시작함
    }

    @Override
    public void onRmsChanged(float rmsdB) {
        //오디오 스트림의 사운드 레벨이 변경됨
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
        //더 많은 소리가 수신됨
    }

    @Override
    public void onEndOfSpeech() {
        //사용자가 말하기를 중지한 후 호출됨

    }

    @Override
    public void onError(int error) {
        //네트워크 또는 인식오류가 발생하면 호출됨

        String message;

        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO:
                message = "오디오 에러";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                message = "클라이언트 에러";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "퍼미션 없음";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                message = "네트워크 에러";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "네트웍 타임아웃";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "찾을 수 없음";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "RECOGNIZER가 바쁨";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                message = "서버가 이상함";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "말하는 시간초과";
                break;
            default:
                message = "알 수 없는 오류임";
                break;
        }
        Toast.makeText(context, "에러가 발생하였습니다. : " + message,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResults(Bundle results) {

    }

    @Override
    public void onPartialResults(Bundle partialResults) {

    }

    @Override
    public void onEvent(int eventType, Bundle params) {

    }
}//class end

